insert into person( name, email) values ( 'subhash', 'subhash@email.com');
insert into person( name, email) values ( 'divya', 'divya@email.com');
insert into person( name, email) values ( 'manjunath', 'manjunath@email.com');
insert into person( name, email) values ( 'hariprasad', 'hariprasad@email.com');