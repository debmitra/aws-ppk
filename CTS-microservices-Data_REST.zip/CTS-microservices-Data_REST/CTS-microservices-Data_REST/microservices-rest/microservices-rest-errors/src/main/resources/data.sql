insert into person( name, email) values ( 'subhash', 'subhash@email.com');
insert into person( name, email) values ( 'divya', 'divya@email.com');
insert into person( name, email) values ( 'manjunath', 'manjunath@email.com');
insert into person( name, email) values ( 'hariprasad', 'hariprasad@email.com');
insert into person( name, email) values ( 'bharathi', 'bharathi@email.com');
insert into person( name, email) values ( 'savithri', 'savithri@email.com');
insert into person( name, email) values ( 'surendran', 'surendran@email.com');
insert into person( name, email) values ( 'unni', 'unni@email.com');